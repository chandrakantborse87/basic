<?php

return [
    'adminEmail' => 'admin@example.com',
     'ApiTokenKey'=>'fa469e393f632',
];
