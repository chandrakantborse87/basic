<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1>Hello</h1>

    <p>
        HelloHelloHelloHelloHelloHelloHelloHello   <?php echo $name; ?>
    </p>

    <code><?= __FILE__ ?></code>
</div>
