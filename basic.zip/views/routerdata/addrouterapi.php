<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Routerdata */

$this->title = 'Add router data';
$this->params['breadcrumbs'][] = ['label' => 'Routerdatas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="routerdata-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_formapi', [
        'model' => $model,
    ]) ?>

</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">

    $(document).ready(function () {
$("#apicall").click(function(){
	alert("test");
    $.ajax({
            type: 'POST',
            url: 'http://localhost/basic/web/index.php?r=api/routerdata/get-token',

         //   dataType: "json",

            crossDomain: true,
            success: function (msg) {
console.log(msg.data);
                alert("success");

            },
            error: function (request, status, error) {

                alert(error);
            }
        });
});
        
    });

</script>