-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 01, 2018 at 08:54 PM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yii2basic`
--

-- --------------------------------------------------------

--
-- Table structure for table `router`
--

DROP TABLE IF EXISTS `router`;
CREATE TABLE IF NOT EXISTS `router` (
  `Sapid` varchar(18) NOT NULL,
  `Hostname` varchar(14) NOT NULL,
  `Loopback` varchar(15) NOT NULL,
  `Mac_address` varchar(17) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `routerdata`
--

DROP TABLE IF EXISTS `routerdata`;
CREATE TABLE IF NOT EXISTS `routerdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Sapid` varchar(18) NOT NULL,
  `Hostname` varchar(14) NOT NULL,
  `Loopback` varchar(15) NOT NULL,
  `Mac_address` varchar(17) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routerdata`
--

INSERT INTO `routerdata` (`id`, `Sapid`, `Hostname`, `Loopback`, `Mac_address`) VALUES
(5, 'dsd', 'sdd', 'dsds', '10.9.112.14'),
(6, 'd454554545tttt', '5465456565', '44565', '10.9.112.45'),
(7, 'dsd', 'dssd', 'dsd', '10.9.112.78');

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
CREATE TABLE IF NOT EXISTS `token` (
  `ip` varchar(15) NOT NULL,
  `token` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`ip`, `token`) VALUES
('::1', '88a9bc941f42632975c42aa68a385f7e'),
('::1', '5e81d922b787eea3ab0ddd85c2ee7d18'),
('::1', '0222eea648344501e27ac13f5625c7ae');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
