<?php

namespace app\modules\api\controllers;

class RouterdataController extends \yii\web\Controller
{
	public $enableCsrfValidation=false;
    public function actionIndex()
    {
    	echo "this is test"; die;
        return $this->render('index');
    }
 public function actionGetToken()
    {
    	\YII::$app->response->format = \YII\web\Response::FORMAT_JSON;
    //	$routerData = Routerdata();
    	$token = md5(uniqid(time().$_SERVER['REMOTE_ADDR'], true));
    	$ip = $_SERVER['REMOTE_ADDR'];

\Yii::$app->db->createCommand("insert into token(ip,token) values('".$ip."','".$token."')")
->execute();

    	return  array('status' => true,'data'=>$token );
    	
    }
    public function actionValidateToken()
    {
    	\YII::$app->response->format = \YII\web\Response::FORMAT_JSON;
    //	$routerData = Routerdata();
    	$tokenData = \YII::$app->request->post();
    	$ip = $_SERVER['REMOTE_ADDR'];
    	$token = $tokenData['token'];

$tokenExist = \Yii::$app->db->createCommand("select * from token where ip = '".$ip."' and token = '".$token."'")->queryAll();
if($tokenExist){
	return  array('status' => true,'data'=>'success' );
}else{
	return  array('status' => false,'data'=>'incorrect token' );
}

    	
    	
    }
   
 public function actionAddRouter()
    {
    	\YII::$app->response->format = \YII\web\Response::FORMAT_JSON;
    //	$routerData = Routerdata();
    	$routerData = new \app\modules\api\models\Routerdata();
    	$routerData->attributes = \YII::$app->request->post();
    	if($routerData->validate()){
    		$routerData->save();
    		return  array('status' => true,'data'=>'router added successfully' );
    	}else{
    		return  array('status' => false, 'data'=> $routerData->getErrors() );
    	}
    	
    }
     public function actionGetRouter()
    {
    	\YII::$app->response->format = \YII\web\Response::FORMAT_JSON;
    //	$routerData = Routerdata();
    	//SELECT * FROM routerdata WHERE REPLACE(Mac_address,'.','') BETWEEN '10911213' AND '10911270'
    	$routerData = new \app\modules\api\models\Routerdata();
    	$routerDataArray = $routerData::find()->all();
    	if(count($routerDataArray)>0){
    		
    		return  array('status' => true,'data'=>$routerDataArray);
    	}else{
    		return  array('status' => false, 'data'=> 'No data found' );
    	}
    	
    }
     public function actionGetRouterbyip()
    {
    	\YII::$app->response->format = \YII\web\Response::FORMAT_JSON;
    //	$routerData = Routerdata();
    	//SELECT * FROM routerdata WHERE REPLACE(Mac_address,'.','') BETWEEN '10911213' AND '10911270'
    	$routerData = new \app\modules\api\models\Routerdata();
    	$data = \YII::$app->request->post();
    	$start_ip = str_replace(".","",$data['start_ip']);
    	$end_ip =  str_replace(".","",$data['end_ip']);
    	$routerDataArray = $routerData::find()->where('  REPLACE(Mac_address,".","") between  "'.  $start_ip . '" AND "'.  $end_ip . '"' )->all();
    	if(count($routerDataArray)>0){
    		
    		return  array('status' => true,'data'=>$routerDataArray);
    	}else{
    		return  array('status' => false, 'data'=> 'No data found' );
    	}
    	
    }
    public function actionDeleteRouterbyip()
    {
    	\YII::$app->response->format = \YII\web\Response::FORMAT_JSON;
    //	$routerData = Routerdata();
    	//SELECT * FROM routerdata WHERE REPLACE(Mac_address,'.','') BETWEEN '10911213' AND '10911270'
    	$routerData = new \app\modules\api\models\Routerdata();
    	$data = \YII::$app->request->post();
    	$ip = $data['ip'];
    	
    	if($routerData::deleteAll('Mac_address = :Mac_address ', [':Mac_address' => $ip])){
    		
    		return  array('status' => true,'data'=>'record deleted');
    	}else{
    		return  array('status' => false, 'data'=> 'No data found' );
    	}
    	
    }

     public function actionGetRouterbysapid()
    {
    	\YII::$app->response->format = \YII\web\Response::FORMAT_JSON;
    //	$routerData = Routerdata();
    	//SELECT * FROM routerdata WHERE REPLACE(Mac_address,'.','') BETWEEN '10911213' AND '10911270'
    	$routerData = new \app\modules\api\models\Routerdata();
    	$data = \YII::$app->request->post();
    	$routerDataArray = $routerData::find()->where('sapid like "%AGI%" or sapid like "%CSS%"')->all();
    	if(count($routerDataArray)>0){
    		
    		return  array('status' => true,'data'=>$routerDataArray);
    	}else{
    		return  array('status' => false, 'data'=> 'No data found' );
    	}
    	
    }

      public function actionUpdateRouterbyid()
    {
    	\YII::$app->response->format = \YII\web\Response::FORMAT_JSON;
    //	$routerData = Routerdata();
    	//SELECT * FROM routerdata WHERE REPLACE(Mac_address,'.','') BETWEEN '10911213' AND '10911270'
    	$routerData = new \app\modules\api\models\Routerdata();
    	$data = \YII::$app->request->post();
    	
\Yii::$app->db->createCommand("UPDATE routerdata SET Sapid='".$data['Sapid']."', Hostname='".$data['Hostname']."', Loopback='".$data['Loopback']."' WHERE Mac_address=:Mac_address")
->bindValue(':Mac_address', $data['Mac_address'])
->execute();
    	return  array('status' => true,'data'=>'updated successfully');
    	
    }
    
}
