<?php

namespace app\modules\api\models;

use Yii;

/**
 * This is the model class for table "routerdata".
 *
 * @property int $id
 * @property string $Sapid
 * @property string $Hostname
 * @property string $Loopback
 * @property string $Mac_address
 */
class Routerdata extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'routerdata';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
              [['Sapid', 'Hostname', 'Loopback', 'Mac_address'], 'required'],
            [['Sapid'], 'match', 'pattern' => '/^[A-Za-z0-9_@%&*]{6,32}$/'],
            [['Sapid'], 'string', 'min' => 18,'max' => 18],
             [['Hostname'], 'match', 'pattern' => '/^[A-Z0-9_@%&*]{6,32}$/'],
              [['Hostname'], 'unique'],
            [['Hostname'], 'string', 'min' => 14,'max' => 14],
              [['Loopback'], 'unique'],
            [['Loopback'], 'match', 'pattern' => '/^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/'],
            [['Loopback'], 'string',  'min' => 7, 'max' => 15],
            [['Mac_address'], 'match', 'pattern' => '/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/'],
            [['Mac_address'], 'string', 'min' => 17,'max' => 17],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Sapid' => 'Sapid',
            'Hostname' => 'Hostname',
            'Loopback' => 'Loopback',
            'Mac_address' => 'Mac Address',
        ];
    }
}
